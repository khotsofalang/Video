function isRequired() {
  document.getElementById("disease_name").required = true;
  document.getElementById("medication").required = true;
  document.getElementById("dosage_form").required = true;
  document.getElementById("schedule").required = true;
  document.getElementById("act_ingredients").required = true;
  document.getElementById("quantity").required = true;
  document.getElementById("repeats").required = true;
  document.getElementById("instructions").required = true;
  document.getElementById("prescription_date").required = true;
}

function notRequired() {
  document.getElementById("disease_name").required = false;
  document.getElementById("medication").required = false;
  document.getElementById("dosage_form").required = false;
  document.getElementById("schedule").required = false;
  document.getElementById("act_ingredients").required = false;
  document.getElementById("quantity").required = false;
  document.getElementById("repeats").required = false;
  document.getElementById("instructions").required = false;
  document.getElementById("prescription_date").required = false;
}