var getDate = new Date();
var getThisYear = getDate.getFullYear();
document.getElementById("year").innerHTML = getThisYear;
