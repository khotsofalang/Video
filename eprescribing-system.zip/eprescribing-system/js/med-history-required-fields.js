function isRequired() {
  document.getElementById("disease_name").required = true;
  document.getElementById("medication").required = true;
  document.getElementById("med_date").required = true;
}

function notRequired() {
  document.getElementById("disease_name").required = false;
  document.getElementById("medication").required = false;
  document.getElementById("med_date").required = false;
}