<!DOCTYPE html>
<html lang="en-US">
<head>
<title>Patient Signup | E-Prescribing</title>
<?php include 'php-html/head-content.php'; ?>
<link rel="stylesheet" href="css/header.css">
<link rel="stylesheet" href="css/external-navbar.css">
<link rel="stylesheet" href="css/sign-up.css">
<link rel="stylesheet" href="css/footer.css">
</head>
<body>
<!-- Header -->
<div class="header">
	<h2>
		<a href="index.php"><i class="fa fa-plus-square"></i></a>
		<a href="index.php">E-Prescribing System</a>
		<a href="index.php"><button>Log in</button></a>
	</h2>
</div>
<!-- Navigation Bar -->
<div class="nav-tabs">
	<div id="active" class="tab">
		<a href="index.php">Patient</a>
	</div>
	<div class="tab" style="border-left: 1px solid #04ae70;">
		<a href="doctor-login.php">Doctor</a>
	</div>
	<div class="tab" style="border-left: 1px solid #04ae70;">
		<a href="pharmacist-login.php">Pharmacist</a>
	</div>
</div>
<!-- Main Content -->
<form class="form-content" action="php/data-patient-signup.php" method="POST" enctype="multipart/form-data" autocomplete="on">
	<h2>Patient Sign Up</h2>

	<fieldset>
		<legend>Personal Details</legend>

		<label for="name">First Names:</label><br>
		<input type="text" name="name" id="name" pattern="[A-Z a-z]{0,}" title="First Name must contain alphabetic characters only." required autofocus><br>

		<label for="surname">Surname:</label><br>
		<input type="text" name="surname" id="surname" pattern="[A-Z a-z]{0,}" title="Surname must contain alphabetic characters only." required><br>

		<label for="birth">Date Of Birth:</label><br>
		<input type="date" name="birth" id="birth" required><br>

		<label for="id_num">ID Number:</label><br>
		<input type="text" name="id_num" id="id_num" pattern="[0-9]{13}" title="ID Number must contain 13 numbers." required><br>

		<label for="gender">Gender:</label>
		<input type="radio" id="male" name="gender" value="Male" required> Male 
		<input type="radio" id="female" name="gender" value="Female" required> Female<br>
	</fieldset>

	<fieldset>
		<legend>Address</legend>

		<label for="street">Street Name:</label><br>
		<input type="text" name="street" id="street" required><br>

		<label for="suburb">Suburb Name:</label><br>
		<input list="suburb" name="suburb" class="data-list" id="data_suburb" required>
		<datalist id="suburb">
			<?php include 'php-html/city_town.php' ?>
		</datalist><br>
		<label for="town">Town Name:</label><br>
		<input list="town" name="town" class="data-list" id="data_town" required>
		<datalist id="town">
			<?php include 'php-html/city_town.php' ?>
		</datalist><br>

		<label for="province">Province Name:</label><br>
		<select name="province" id="province" onfocus="sortListInput('province')" required>
			<option selected disabled></option>
			<option value="Eastern Cape">Eastern Cape</option>
			<option value="Free State">Free State</option>
			<option value="Gauteng">Gauteng</option>
			<option value="KwaZulu-Natal">KwaZulu-Natal</option>
			<option value="Limpopo">Limpopo</option>
			<option value="Mpumalanga">Mpumalanga</option>
			<option value="North West">North West</option>
			<option value="Western Cape">Western Cape</option>
			<option value="Northern Cape">Northern Cape</option>
		</select><br>
        
        <label for="code">Postal Code:</label><br>
		<input list="code" name="code" class="data-list" id="data_code" pattern="[0-9]{4}" title="Postal Code must contain 4 numbers." required>
		<datalist id="code">
			<?php include 'php-html/postal_codes.php' ?>
        </datalist><br>
		
	</fieldset>
	
	<fieldset>
		<legend>Contact Details</legend>

		<label for="contact_num">Contact Number:</label><br>
		<input type="tel" name="contact_num" id="contact_num" pattern="[0-9]{10}" title="Contact Number must contain 10 numbers." required><br>

		<label for="email">Email:</label><br>
		<input type="email" name="email" id="email" autocomplete="off" required><br>
		
		<label for="verify_email">Verify Email:</label><br> 
		<input type="email" name="verify_email" id="verify_email" autocomplete="off" required><br>
		
		<div class="validation">
			<span id="matchEmail" class="invalid"><i class="fa">&#xf058;</i> Emails must match</span><br> 
		</div>
	</fieldset>
		
	<fieldset>
		<legend>Password</legend>
		
		<label for="pswd">Create Password:</label><br>
		<input type="password" id="pswd" name="pswd" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}" title="Password must contain at least one lowercase and uppercase letter, at least one number and must be least 7 or more characters." required>
		
		<div class="validation">
			<span id="length" class="invalid"><i class="fa">&#xf058;</i> Password must be a minimum of 7 characters</span><br>
			<span id="letter" class="invalid"><i class="fa">&#xf058;</i> Password must contain a lowercase letter</span><br>
			<span id="capital" class="invalid"><i class="fa">&#xf058;</i> Password must contain an uppercase/capital letter</span><br>
			<span id="number" class="invalid"><i class="fa">&#xf058;</i> Password must contain a number</span><br>
		</div>
		
		<label for="confirm_pswd">Confirm Password:</label><br>
		<input type="password" id="confirm_pswd" name="confirm_pswd" required><br>
		
		<div class="validation">
			<span id="matchPass" class="invalid"><i class="fa">&#xf058;</i> Passwords must match</span><br> 
		</div>
		
		<input type="submit" value="Submit" id="btnSubmit" name="btnSubmit">
		<input type="reset" value="Clear" id="btnClear" name="btnClear">
	</fieldset>
</form>
<!-- Footer -->
<?php include 'php-html/footer.php'; ?>
<script src="js/sort-input-elements.js"></script>
<script src="js/form-validations.js"></script>
<script src="js/date.js"></script>
</body>
</html>