<br><hr>
<div class="footer">
	<a href="">Copyright &copy; E-Prescribing System SA <span id="year"></span>. All Rights Reserved.</a><br>
	<a href="https://web.facebook.com/?_rdc=1&_rdr" target="_blank"><i class="fa fa-facebook" title="Facebook"></i></a>
	<a href="https://twitter.com/" target="_blank"><i class="fa fa-twitter" title="Twitter"></i></a>
	<a href="https://www.instagram.com/" target="_blank"><i class="fa fa-instagram" target="_blank" title="Instagram"></i></a>
	<a href="https://www.linkedin.com/" target="_blank" title="Linkedin"><i class="fa fa-linkedin"></i></a>
</div>