<?php

if (isset($_POST['btnlogout'])) {
	session_start();
	session_unset();
	session_destroy();
	header("Location: ../pharmacist-login.php");
	exit();
}