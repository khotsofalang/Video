<?php
session_start();

if (isset($_GET['alert-reason']) && isset($_GET['test'])) {

	include_once 'data-connection.php'; 

	$message = mysqli_real_escape_string($conn, $_GET['alert-reason']);
	$pharm = mysqli_real_escape_string($conn, $_SESSION['dispense_pharm_reg_num']);
	$prescription_id = mysqli_real_escape_string($conn, $_SESSION['prescriptions_id']);

	$sql = "INSERT INTO ALERT_MESSAGE (MESSAGE, PHARMACIST_ID, PRESCRIPTION_ID)
	VALUES ('$message', '$pharm', '$prescription_id');";
	if (mysqli_query($conn, $sql)) {
  		echo("<script>alert('Capture Alert Reason Successful')</script>");
  		if($_GET['test'] == 1){
 			echo("<script>window.location = 'data-dispense-prescription.php?dispense_days_checked=yes';</script>");
 		} else {
 			echo("<script>alert('Capture Alert Reason Unsuccessful: Something went wrong, Please try again.')</script>");
 			echo("<script>window.location = '../data-dispense-prescription.php?capture-alert-reason=error';</script>");
 			mysqli_close($conn);
			exit();
 		}
 		mysqli_close($conn);
		exit(); 
	} else {
 		echo("<script>alert('Capture Alert Reason Unsuccessful: Something went wrong, Please try again.')</script>");
 		echo("<script>window.location = '../pharmacist-dispense-prescription.php?capture-alert-reason=error';</script>");
 		mysqli_close($conn);
		exit(); 
	}
}else{
	session_unset();
	session_destroy();
	header("Location: ../pharmacist-login.php?dispense-prescription=error");
	mysqli_close($conn);
	exit(); 
}