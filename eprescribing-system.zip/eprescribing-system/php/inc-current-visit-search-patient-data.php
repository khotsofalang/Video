<?php
$_SESSION['current_visit_id_num'] = "";

if(isset($_SESSION['current-visit-id-num'])) {
	$_SESSION['current_visit_id_num'] = $_SESSION['current-visit-id-num'];
}
?>