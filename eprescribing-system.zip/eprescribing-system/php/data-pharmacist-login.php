<?php
session_start();
//Security: Avoid people login illegal
if (isset($_POST['btnLogin'])) {
	//Get database connection
	include 'data-connection.php';

	$user_name = mysqli_real_escape_string($conn, $_POST['user_name']);
	$pswd = mysqli_real_escape_string($conn, $_POST['pswd']);
		
	$sql = "SELECT * FROM PHARMACIST WHERE REGISTRATION_NUM ='$user_name' OR EMAIL='$user_name'";
	$result = mysqli_query($conn, $sql);
	$resultCheck = mysqli_num_rows($result);
	if($resultCheck < 1){
		echo'<script>window.alert("Login Unsuccessful: Username or password you entered is incorrect, Please try again.");</script>';
		echo("<script>window.location = '../pharmacist-login.php?login=error';</script>");
 		mysqli_close($conn);
		exit();
	}else{
		if($row = mysqli_fetch_assoc($result)){
			if ($pswd == $row['PASSWORD']){

				$sql1 = "SELECT * FROM PHARMACY WHERE LICENSE_NUM = '".$row['PHARMACY_ID']."'";
				$result1 = mysqli_query($conn, $sql1);
				$resultCheck1 = mysqli_num_rows($result1);
				if($resultCheck1 > 0){
					if ($row1 = mysqli_fetch_assoc($result1)) {
						
						$sql2 = "SELECT * FROM ADDRESS WHERE ADDRESS_ID = '".$row1['PHARM_ADDRESS']."'";
						$result2 = mysqli_query($conn, $sql2);
						$resultCheck2 = mysqli_num_rows($result2);
						if($resultCheck2 > 0){
							if ($row2 = mysqli_fetch_assoc($result2)) {
								$_SESSION['pharm_reg_num'] = $row['REGISTRATION_NUM'];
								$_SESSION['pharm_name'] = $row['NAME'];
								$_SESSION['pharm_surname'] = $row['SURNAME'];
								$_SESSION['pharm_contact_num'] = $row['CONTACT_NUMBER'];
								$_SESSION['pharm_alt_num'] = $row['ALT_CONTACT_NUMBER'];
								$_SESSION['pharm_email'] = $row['EMAIL'];
								$_SESSION['pharm_pharmacy_id'] = $row['PHARMACY_ID'];
								$_SESSION['pharm_password'] = $row['PASSWORD'];

								$_SESSION['pharmacy_name'] = $row1['NAME'];
								$_SESSION['pharmacy_address'] = $row1['PHARM_ADDRESS'];
								$_SESSION['pharmacy_contact_num'] = $row1['CONTACT_NUMBER'];
								$_SESSION['pharmacy_email'] = $row1['EMAIL'];

								$_SESSION['pharmacy_street'] = $row2['STREET'];
								$_SESSION['pharmacy_suburb'] = $row2['SUBURB'];
								$_SESSION['pharmacy_town'] = $row2['TOWN'];
								$_SESSION['pharmacy_province'] = $row2['PROVINCE'];
								$_SESSION['pharmacy_code'] = $row2['CODE'];

								header("Location: ../pharmacist-home.php?login=success");
								mysqli_close($conn);
								exit();
							}

						}else{
							echo("<script>alert('Login Unsuccessful:33 Something went wrong, Please try again.')</script>");
				 			echo("<script>window.location = '../index.php?login=error';</script>");
				 			mysqli_close($conn);
							exit();
						}

					}
				}else{
					echo("<script>alert('Login Unsuccessful: Something went wrong, Please try again.')</script>");
		 			echo("<script>window.location = '../index.php?login=error';</script>");
		 			mysqli_close($conn);
					exit();
				}
			}else{
				echo("<script>alert('Login Unsuccessful: Username or password you entered is incorrect, Please try again.')</script>");
	 			echo("<script>window.location = '../pharmacist-login.php?login=error';</script>");
	 			mysqli_close($conn);
				exit();
			}
		}
	}
}else{
	header("Location: ../pharmacist-login.php?login=error");
	session_unset();
	session_destroy();
	mysqli_close($conn);
	exit();
}