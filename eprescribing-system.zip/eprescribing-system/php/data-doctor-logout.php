<?php

if (isset($_POST['btnlogout'])) {
	session_start();
	session_unset();
	session_destroy();
	header("Location: ../doctor-login.php");
	exit();
}