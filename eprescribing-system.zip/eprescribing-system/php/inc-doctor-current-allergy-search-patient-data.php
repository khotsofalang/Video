<?php
$_SESSION['current_allergy_id_num'] = "";

if(isset($_SESSION['current-allergy-id-num'])) {
	$_SESSION['current_allergy_id_num'] = $_SESSION['current-allergy-id-num'];
}
?>