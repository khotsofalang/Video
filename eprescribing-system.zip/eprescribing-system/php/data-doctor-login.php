<?php
session_start();
//Security: Avoid people login illegal
if (isset($_POST['btnLogin'])) {
	//Get database connection
	include 'data-connection.php';

	$user_name = mysqli_real_escape_string($conn, $_POST['user_name']);
	$pswd = mysqli_real_escape_string($conn, $_POST['pswd']);
		
	$sql = "SELECT * FROM DOCTOR WHERE REGISTRATION_NUM ='$user_name' OR EMAIL='$user_name'";
	$result = mysqli_query($conn, $sql);
	$resultCheck = mysqli_num_rows($result);
	if($resultCheck < 1){
		echo'<script>window.alert("Login Unsuccessful: Username or password you entered is incorrect, Please try again.");</script>';
		echo("<script>window.location = '../doctor-login.php?login=error';</script>");
 		mysqli_close($conn);
		exit();
	}else{
		if($row = mysqli_fetch_assoc($result)){
			if ($pswd == $row['PASSWORD']){

				$sql1 = "SELECT * FROM MEDICAL_PRACTICE WHERE PRACTICE_NUM = '".$row['PRACTICE_NUM']."'";
				$result1 = mysqli_query($conn, $sql1);
				$resultCheck1 = mysqli_num_rows($result1);
				if($resultCheck1 > 0){
					if ($row1 = mysqli_fetch_assoc($result1)) {
						
						$sql2 = "SELECT * FROM ADDRESS WHERE ADDRESS_ID = '".$row1['PRACTICE_ADDRESS']."'";
						$result2 = mysqli_query($conn, $sql2);
						$resultCheck2 = mysqli_num_rows($result2);
						if($resultCheck2 > 0){
							if ($row2 = mysqli_fetch_assoc($result2)) {
								$_SESSION['doc_reg_num'] = $row['REGISTRATION_NUM'];
								$_SESSION['doc_name'] = $row['NAME'];
								$_SESSION['doc_surname'] = $row['SURNAME'];
								$_SESSION['doc_contact_num'] = $row['CONTACT_NUMBER'];
								$_SESSION['doc_email'] = $row['EMAIL'];
								$_SESSION['doc_qualification'] = $row['QUALIFICATION'];
								$_SESSION['doc_practice_num'] = $row['PRACTICE_NUM'];
								$_SESSION['doc_password'] = $row['PASSWORD'];

								$_SESSION['med_practice_name'] = $row1['NAME'];
								$_SESSION['med_practice_address'] = $row1['PRACTICE_ADDRESS'];
								$_SESSION['med_practice_contact_num'] = $row1['CONTACT_NUMBER'];
								$_SESSION['med_practice_email'] = $row1['EMAIL'];

								$_SESSION['med_practice_street'] = $row2['STREET'];
								$_SESSION['med_practice_suburb'] = $row2['SUBURB'];
								$_SESSION['med_practice_town'] = $row2['TOWN'];
								$_SESSION['med_practice_province'] = $row2['PROVINCE'];
								$_SESSION['med_practice_code'] = $row2['CODE'];

								header("Location: ../doctor-home.php?login=success");
								mysqli_close($conn);
								exit();
							}

						}else{
							echo("<script>alert('Login Unsuccessful:33 Something went wrong, Please try again.')</script>");
				 			echo("<script>window.location = '../index.php?login=error';</script>");
				 			mysqli_close($conn);
							exit();
						}

					}
				}else{
					echo("<script>alert('Login Unsuccessful: Something went wrong, Please try again.')</script>");
		 			echo("<script>window.location = '../index.php?login=error';</script>");
		 			mysqli_close($conn);
					exit();
				}

			}else{
				echo("<script>alert('Login Unsuccessful: Username or password you entered is incorrect, Please try again.')</script>");
	 			echo("<script>window.location = '../doctor-login.php?login=error';</script>");
	 			mysqli_close($conn);
				exit();
			}
		}
	}
}else{
	header("Location: ../doctor-login.php?login=error");
	session_unset();
	session_destroy();
	mysqli_close($conn);
	exit();
}