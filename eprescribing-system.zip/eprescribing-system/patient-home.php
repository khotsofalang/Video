<?php include 'php/data-patient-loggedin.php' ?>
<!DOCTYPE html>
<html lang="en-US">
<head>
<title>Patient Home | E-Prescribing</title>
<?php include 'php-html/head-content.php'; ?>
<link rel="stylesheet" href="css/header.css">
<link rel="stylesheet" href="css/internal-navbar.css">
<link rel="stylesheet" href="css/sign-up.css">
<link rel="stylesheet" href="css/footer.css">
</head>
<body>
<!-- Header -->
<div class="header">
	<h2>
		<a href="patient-home.php"><i class="fa fa-plus-square"></i></a>
		<a href="patient-home.php">E-Prescribing System</a>
		<form action="php/data-patient-logout.php" method="POST">
			<button name="btnlogout" id="btnlogout">log out</button>
		</form>
	</h2>
</div>
<!-- Navigation Bar -->
<div class="topnav" id="myTopnav">
	<a id="active" href="patient-home.php">Home</a>
	<a href="patient-view-prescriptions.php">View Prescriptions</a>
	<a href="patient-medical-history.php">Medical History</a>
	<a href="patient-allergy-history.php">Allergy History</a>
	<a href="javascript:void(0);" class="icon" onclick="ResponsiveNav()">&#9776;</a>
</div>
<script src="http://localhost/Rez-Online-App/js/responsiveNav.js"></script>
<!-- Main Content -->
<form class="form-content" action="php/data-patient-update.php" method="POST" enctype="multipart/form-data" autocomplete="on">
	<?php
	echo '<h2>Welcome '.$_SESSION['pat_name'].' '.$_SESSION['pat_surname'].'</h2>

	<fieldset>
		<legend>Personal Details</legend>

		<label for="id_num">ID Number:</label><br>
		<input type="text" name="id_num" id="id_num" value="'.$_SESSION['pat_id_num'].'" title="This field cannot be changed." disabled><br>

		<label for="name">First Names:</label><br>
		<input type="text" name="name" id="name" value="'.$_SESSION['pat_name'].'" title="This field cannot be changed." disabled><br>

		<label for="surname">Surname:</label><br>
		<input type="text" name="surname" id="surname" value="'.$_SESSION['pat_surname'].'" title="This field cannot be changed." disabled><br>

		<label for="birth">Date Of Birth:</label><br>
		<input type="text" name="birth" id="birth" value="'.$_SESSION['pat_birth'].'" title="This field cannot be changed." disabled><br>

		<label for="gender">Gender:</label><br>
		<input type="text" name="gender" id="gender" value="'.$_SESSION['pat_gender'].'" title="This field cannot be changed." disabled><br>
	</fieldset>
    
	<fieldset>
		<legend>Address</legend>
		
		<label for="street">Street Name:</label><br>
		<input type="text" name="street" id="street" value="'.$_SESSION['pat_street'].'" required><br>

		<label for="suburb">Suburb Name:</label><br>
		<input list="suburb" name="suburb" class="data-list" id="data_suburb" value="'.$_SESSION['pat_suburb'].'" required>
		<datalist id="suburb">';?>
			<?php include 'php-html/city_town.php' ?>
			<?php echo '
		</datalist><br>

		<label for="town">Town Name:</label><br>
		<input list="town" name="town" class="data-list" id="data_town" value="'.$_SESSION['pat_town'].'" required>
		<datalist id="town">';?>
			<?php include 'php-html/city_town.php' ?>
			<?php echo '
		</datalist><br>

		<label for="province">Province Name:</label><br>
		<select name="province" id="province" required>
			<option selected value="'.$_SESSION['pat_province'].'">'.$_SESSION['pat_province'].'</option>
			<option value="Eastern Cape">Eastern Cape</option>
			<option value="Free State">Free State</option>
			<option value="Gauteng">Gauteng</option>
			<option value="KwaZulu-Natal">KwaZulu-Natal</option>
			<option value="Limpopo">Limpopo</option>
			<option value="Mpumalanga">Mpumalanga</option>
			<option value="North West">North West</option>
			<option value="Northern Cape">Northern Cape</option>
			<option value="Western Cape">Western Cape</option>
		</select><br>

		<label for="code">Postal Code:</label><br>
		<input list="code" name="code" class="data-list" id="data_code" value="'.$_SESSION['pat_code'].'" required>
		<datalist id="code">';?>
			<?php include 'php-html/postal_codes.php' ?>
			<?php echo '
		</datalist><br>
	</fieldset>
		
	<fieldset>
		<legend>Contact Details</legend>

		<label for="contact_num">Contact Number:</label><br>
		<input type="tel" name="contact_num" id="contact_num" value="'.$_SESSION['pat_contact_num'].'" pattern="[0-9]{10}" title="Contact Number must contain 10 numbers." required><br>

		<label for="email">Email:</label><br>
		<input type="email" name="email" value="'.$_SESSION['pat_email'].'" id="email"  autocomplete="off" required><br>
		
		<label for="verify_email">Verify Email:</label><br> 
		<input type="email" name="verify_email" id="verify_email" autocomplete="off" required><br>
		
		<div class="validation">
			<span id="matchEmail" class="invalid"><i class="fa">&#xf058;</i> Emails must match</span><br> 
		</div>
	</fieldset>
	';?>
	<fieldset>
		<legend>Password</legend>
		
		<label for="pswd">Create New Password:</label><br>
		<input type="password" id="pswd" name="pswd" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,}" title="Password must contain at least one lowercase and uppercase letter, at least one number and must be least 7 or more characters." required>
		
		<div class="validation">
			<span id="length" class="invalid"><i class="fa">&#xf058;</i> Password must be a minimum of 7 characters</span><br>
			<span id="letter" class="invalid"><i class="fa">&#xf058;</i> Password must contain a lowercase letter</span><br>
			<span id="capital" class="invalid"><i class="fa">&#xf058;</i> Password must contain an uppercase/capital letter</span><br>
			<span id="number" class="invalid"><i class="fa">&#xf058;</i> Password must contain a number</span><br>
		</div>
		
		<label for="confirm_pswd">Confirm New Password:</label><br>
		<input type="password" id="confirm_pswd" name="confirm_pswd" required><br>
		
		<div class="validation">
			<span id="matchPass" class="invalid"><i class="fa">&#xf058;</i> Passwords must match</span><br> 
		</div>

		<label for="current_pswd">Current Password:</label><br>
		<input type="password" id="current_pswd" name="current_pswd" required><br>
		
		<input type="submit" value="Update" id="btnSubmit" name="btnSubmit">
	</fieldset>
	
</form>
<!-- Footer -->
<?php include 'php-html/footer.php'; ?>
<script src="js/form-validations.js"></script>
<script src="js/date.js"></script>
</body>
</html>